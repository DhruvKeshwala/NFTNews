/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'th', {
	block: 'จัดพอดีหน้ากระดาษ',
	center: 'จัดกึ่งกลาง',
	left: 'จัดชิดซ้าย',
	right: 'จัดชิดขวา'
} );
